import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'pairing.dart';

import 'models.dart';
import 'theme.dart';

/// Ícone do app (o mesmo do menu do celular do filho). Sem ícone, mostra a
/// letra inicial em um círculo colorido.
class AppAvatar extends StatelessWidget {
  const AppAvatar(this.app, {super.key, this.size = 40});

  final InstalledApp app;
  final double size;

  // Decodificar o base64 a cada desenho de lista pesaria; guarda o resultado.
  static final Map<String, Uint8List?> _decoded = {};

  static Uint8List? _bytes(InstalledApp app) {
    final icon = app.icon;
    if (icon == null || icon.isEmpty) return null;
    final key = '${app.id}:${icon.length}:${icon.hashCode}';
    return _decoded.putIfAbsent(key, () {
      try {
        return base64Decode(icon);
      } on FormatException {
        return null;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final letter = app.name.trim().isEmpty
        ? '?'
        : app.name.trim()[0].toUpperCase();
    final hue = (app.id.hashCode.abs() % 360).toDouble();
    final dark = Theme.of(context).brightness == Brightness.dark;
    final bg = HSLColor.fromAHSL(1, hue, 0.45, dark ? 0.30 : 0.82).toColor();
    final fg = HSLColor.fromAHSL(1, hue, 0.55, dark ? 0.85 : 0.25).toColor();
    final bytes = _bytes(app);
    final radius = BorderRadius.circular(size * 0.3);
    final fallback = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: bg, borderRadius: radius),
      child: Text(
        letter,
        style: TextStyle(
          color: fg,
          fontWeight: FontWeight.w700,
          fontSize: size * 0.45,
        ),
      ),
    );
    return ExcludeSemantics(
      child: bytes == null
          ? fallback
          : ClipRRect(
              borderRadius: radius,
              child: Image.memory(
                bytes,
                key: const Key('appIcon'),
                width: size,
                height: size,
                fit: BoxFit.cover,
                gaplessPlayback: true,
                filterQuality: FilterQuality.medium,
                errorBuilder: (_, _, _) => fallback,
              ),
            ),
    );
  }
}

/// Mostra "1 h 30 min", "45 min", "sem limite".
String formatMinutes(int? minutes) {
  if (minutes == null) return 'sem limite';
  if (minutes <= 0) return '0 min';
  final h = minutes ~/ 60;
  final m = minutes % 60;
  if (h == 0) return '$m min';
  if (m == 0) return '$h h';
  return '$h h $m min';
}

/// Mostra "2h 57min", "42 min", "1h" (formato curto das telas novas).
String formatDur(int? minutes) {
  if (minutes == null) return 'sem limite';
  if (minutes <= 0) return '0 min';
  final h = minutes ~/ 60;
  final m = minutes % 60;
  if (h == 0) return '$m min';
  if (m == 0) return '${h}h';
  return '${h}h ${m}min';
}

/// Aviso em destaque (erro, informação).
class Notice extends StatelessWidget {
  const Notice(this.message, {super.key, this.isError = false, this.icon});

  final String message;
  final bool isError;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final bg = isError ? GColors.redSoft : GColors.blueSoft;
    final fg = isError ? GColors.redText : GColors.blue;
    return Semantics(
      liveRegion: true,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              icon ?? (isError ? Icons.error_outline : Icons.info_outline),
              color: fg,
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: TextStyle(color: fg, fontSize: 13.5, height: 1.4),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Deixa o texto em maiúsculas, remove o que não é do código e põe o traço
/// no meio ("k7m29qxa" vira "K7M2-9QXA").
class PairingCodeFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    var raw = normalizePairingCode(newValue.text);
    if (raw.length > pairingCodeLength) {
      raw = raw.substring(0, pairingCodeLength);
    }
    final shown = raw.length > 4
        ? '${raw.substring(0, 4)}-${raw.substring(4)}'
        : raw;
    return TextEditingValue(
      text: shown,
      selection: TextSelection.collapsed(offset: shown.length),
    );
  }
}
